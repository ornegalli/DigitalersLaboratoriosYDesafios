package Ejercicios;

public class n5 {

	public static void main(String[] args) {
		//  n1=5 y n2=10
		
		int n1 = 5;
		int n2 = 10;
		
		//n1 es igual a 5.
	 // n2 es igual a 10.
 // n1 más n2 es igual a 15
	
		System.out.println("n1 es igual a " + n1);
		System.out.println("n2 es igual a " + n2);
		System.out.println("n1 mas n2 es igual a " + (n1+n2));
		
	}

}
