package Ejercicios;

public class Ej7 {

	public static void main(String[] args) {
		int n1= 10;
		int n2 = 20;
		int n3 = 30;
		int total = n1 + n2+ n3;
		int promedio = (n1+n2+n3)/3;
		int resto  = n2%n1;
		
		System.out.println("Total: " + total);
		System.out.println("Promedio: " + promedio);
		System.out.println("Resto entre n1 y n2: " + resto);
		
	}

}
