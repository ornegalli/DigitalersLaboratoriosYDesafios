package Ejercicios;

public class desafio1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("A");
		int x = 10;
		int y=20;
		System.out.println(x);
		System.out.println(y);
		System.out.println("B");
		x = x + 5;
		y = y + 10;
		System.out.println(x);
		System.out.println(y);
		System.out.println("C");
		x = x- 5;
		y = y - 10;
		System.out.println(x);
		System.out.println(y);
		System.out.println("D");
		x = x* 3;
		y = y *5;
		System.out.println(x);
		System.out.println(y);
		System.out.println("E");
		x = x/ 2;
		y = y /4;
		System.out.println(x);
		System.out.println(y);
	}

}
