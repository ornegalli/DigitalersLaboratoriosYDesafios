package Ejercicios;

public class desafio2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("A");
		int x = 10;
		int y=20;
		System.out.println(x);
		System.out.println(y);
		System.out.println("B");
		 x += 5;
		 y -= 15;
		System.out.println(x);
		System.out.println(y);
		System.out.println("C");
		x++;
		y--;
		System.out.println(x);
		System.out.println(y);
		System.out.println("D");
		x*=4 ;
		y*=-3 ;
		System.out.println(x);
		System.out.println(y);
		System.out.println("E");
		x/=2;
		y/=4 ;
		System.out.println(x);
		System.out.println(y);
	}

}
