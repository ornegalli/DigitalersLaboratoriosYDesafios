package Ejercicios;

public class Ej6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n1 = 5;
		int n2 = 10;
		int n3 = 20;

		
 System.out.println(n1 + n2);
 System.out.println(n3 - n1);
 System.out.println(n1 * n3);
 System.out.println(n3 / n2);

	}

}
