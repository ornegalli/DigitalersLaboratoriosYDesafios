package Ejercicios;

public class ej1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
boolean variableA = true;
boolean variableB = false;
boolean variableC = true;

System.out.println("La variableA debe ser " + variableA);
System.out.println("La variableB debe ser " + variableB);
System.out.println("La variableC debe ser " + variableC);
System.out.println("(variableA && variableB) || (variableA && variableC) = " + ((variableA && variableB) || (variableA && variableC)));
System.out.println("!(variableA || variableB) && variableC = " + (!(variableA || variableB) && variableC));
	
	}

}
