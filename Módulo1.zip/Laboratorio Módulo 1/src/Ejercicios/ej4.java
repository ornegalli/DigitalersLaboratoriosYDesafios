package Ejercicios;

public class ej4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
boolean n1 = true;
boolean n2 = false;
boolean n3 = true;

System.out.println("b: " + ((n1 & !n2)| n3 )) ;
System.out.println("c: " + ((n1 | n2) & !n3));

}
}