package Ejercicios;

public class n6ad {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
final double IVA = 21;
double remera = 59.90 , pantalon = 99.90 , campera = 149.90 ; 

System.out.println("El precio final de la remera es " + (remera+remera*IVA/100));
System.out.println("El precio final del pantalon es " + (pantalon+pantalon*IVA/100));
System.out.println("El precio final de la campera es " + (campera+campera*IVA/100));

	}

}
