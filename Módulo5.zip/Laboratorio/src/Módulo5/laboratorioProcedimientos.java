package Módulo5;

import java.util.Scanner;
import java.util.Arrays;

public class laboratorioProcedimientos {
	
	
	
	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		float numeroA, numeroB;
		char operacion;
		char[] operadoresValidos = { '+', '-', '*', '/', '%' };
		boolean operadorValido = false;
		
		System.out.println("Ingrese un numero a: ");
		numeroA = teclado.nextFloat();
		System.out.println("Ingrese un numero b: ");
		numeroB = teclado.nextFloat();
		do {

			System.out.print("Ingrese la operacion que desea realizar " + Arrays.toString(operadoresValidos) + " : ");
			operacion = teclado.next().charAt(0);

			for (int i = 0; i < operadoresValidos.length; i++) {
				if (operacion == operadoresValidos[i]) {
					operadorValido = true;
					break;
				}
				if (operacion != operadoresValidos[i]) {
					System.out.println("Ha indicado un operador no valido...");break;
	
				}
			}

		} while (!operadorValido);
		
		calculo(numeroA, numeroB, operacion);
		
		teclado.close();
	}

		public static void calculo(float numeroA,float numeroB, char operacion) {
			switch(operacion) {
		
				case '+' : System.out.println("El resultado de " + numeroA + operacion + numeroB + " es: " + sumar(numeroA,numeroB));break;
				case '-' : System.out.println("El resultado de " + numeroA + operacion + numeroB + " es: " + restar(numeroA, numeroB));break;
				case '*' : System.out.println("El resultado de " + numeroA + operacion + numeroB + " es: " + multiplicar(numeroA, numeroB));break;
				case '/' : System.out.println("El resultado de " + numeroA + operacion + numeroB + " es: " + dividir(numeroA, numeroB));break;
				case '%' : System.out.println("El resultado de " + numeroA + operacion + numeroB + " es: " + restoDivision(numeroA, numeroB));break;
				default : System.out.println("Ha indicado un operador no valido...");break;
		
			}

		}
		
		public static float sumar(float a, float b) {
			return a + b;
		}

		public static float restar(float a, float b) {
			return a - b;
		}

		public static float multiplicar(float a, float b) {
			return a * b;
		}

		public static float dividir(float a, float b) {
			return a / b;
		}

		public static float restoDivision(float a, float b) {
			return a % b;
		}

		

}
