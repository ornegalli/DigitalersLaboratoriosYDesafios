package Módulo5;

public class laboratorioFunciones3 {

	public static void main(String[] args) {
		
		mensaje("Hola ");
		mensaje("a ");
		mensaje("todos ");
		mensaje("soy ");
		mensaje("Ornella ");
	}
	
	
	public static void mensaje(String palabra) {
		System.out.println(palabra);

}
}
