package Módulo5;

import java.util.Scanner;

public class laboratorioFunciones2 {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		int n1;
		double n2;
		double resultado;
		
		System.out.println("Ingrese un numero entero para la suma");
		n1 = teclado.nextInt();
		
		System.out.println("Ingrese un numero con decimales para la suma");
		n2 = teclado.nextDouble();
		
		teclado.close();
		
		resultado = suma(n1,n2);
		
		System.out.println("El resultado de la suma (" + n1 + " + " + n2 + ")" + " es = " + resultado);
	}

	public static double suma(int n1, double n2) {
		double resultado = n1 + n2;
		
		return resultado;
	}
}
