package Módulo5;

import java.util.Scanner;

public class laboratorioFunciones {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		String oracion = "";

		System.out.println("Escriba la oracion a evaluar (no puede estar vacia)");
		oracion = teclado.nextLine();
		teclado.close();

		capicuaOPalindromo(oracion);
	}

	public static void capicuaOPalindromo(String mensaje) {
		// Hago el arreglo con las palabras de la oracion
		String[] palabras = mensaje.split(" ");
		;

		for (int i = 0; i < palabras.length; i++) {

			// evaluamos si es palindromo y de ser asi evaluamos si es un numero
			System.out.println(palabras[i] + " "
					+ (esPalindromo(palabras[i].trim())
							? (esNumero(palabras[i].trim()) ? "es Capicua" : "es Palindromo")
							: "No es Palindromo"));
		}

		return;
	}

	public static boolean esPalindromo(String palabra) {
		// pasamos las palabras a minusculas para poder comparar todas
		palabra = palabra.toLowerCase();

		// hacemos un ciclo que evalue cada caracter, no es necesario revisar toda la
		// palabra sino la mitad
		for (int i = 0, j = palabra.length() - 1; i < (palabra.length() / 2); i++, j--) {
			if (palabra.charAt(i) != palabra.charAt(j)) {
				return false;
			}
		}

		return true;
	}

	public static boolean esNumero(String palabra) {
		char[] numeros = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };

		for (int i = 0; i < palabra.length(); i++) {
			char caracter = palabra.charAt(i);

			// si el caracter a evaluar esta dentro de los numeros retornamos que es numero
			for (int j = 0; j < numeros.length; j++) {
				if (caracter == numeros[j]) {
					return true;
				}

			}
		}
		return false;
	}
}
