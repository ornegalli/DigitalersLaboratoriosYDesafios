package Módulo5;

import java.util.*;

public class laboratorioArrays {

	public static void main(String[] args) {

		String[] palabras;
		char[] letras;
		int cantidadRepeticiones = 1;
		String palabraAuxiliar = "";

		Scanner teclado = new Scanner(System.in);

		System.out.println("Ingrese una oracion(no puede estar vacia): ");
		String oracion = teclado.nextLine();

		teclado.close();
		// contador de palabras

		// SPLIT retorna un arreglo donde cada elemento esta dividido por el parametro
		// indicado, en este caso los espacios
		palabras = oracion.split(" ");

		System.out.println("La oracion tiene " + palabras.length + " palabras.");

		// indicar si hay palabras repetidas
		int contadorAuxiliar = 0;
		
		for (int i = 0; i < palabras.length; i++) {
			 palabraAuxiliar = palabras[i];
			
			for (int j = i + 1; j < palabras.length; j++) {

				if (palabras[j].equals(palabraAuxiliar)) {
					contadorAuxiliar++;
				}

				if (contadorAuxiliar > cantidadRepeticiones) {
					cantidadRepeticiones = contadorAuxiliar;
			
				}
			}

		}
		System.out.println ("En la oración hay " + contadorAuxiliar + " palabras repetidas ");

		// ordenar las palabras de forma ascendente

		Arrays.sort(palabras); // Array.sort ordena el arreglo alfabeticamente
		System.out.println("Palabras Ordenadas: ");
		System.out.println(Arrays.toString(palabras));

		// ordenar las letras
		oracion = oracion.replace(" ", "");
		oracion = oracion.replace(",", "");// este método reemplaza un caracter por otro, para no contar los espacios
		letras = oracion.toCharArray(); // este metodo retorna el arreglo con caracteres
		Arrays.sort(letras);
		System.out.println("Letras Ordenadas: ");
		System.out.println(Arrays.toString(letras));

	}

}
