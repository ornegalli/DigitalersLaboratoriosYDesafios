package Módulo5;

public class desafio2y3 {

	public static void main(String[] args) {
		double[] inflacion= {0.8, 0.1, 0.3, 0.4, 0.3, 0.6, 0.5, 0.3, 0.7, 0.3, 0.2, 0.9};
		String[] mes={"enero","febrero","marzo","abril","mayo","junio","julio","agosto","septiembre","octubre",
				"noviembre","diciembre"};
		double  anual = 0, masBaja = inflacion[0], masAlta = inflacion[0];
		int n;
		String mes_max = "", mes_min = "";
		
		for(n = 0; n < inflacion.length; n++) {
			anual = anual + inflacion[n];
			if(inflacion[n] > masAlta) {
				masAlta = inflacion[n];
				mes_max = mes[n];
			}
			if(inflacion[n] < masBaja) {
				masBaja = inflacion[n];
				mes_min = mes[n];
			}
		}
		
		
		System.out.println("La inflacion anual es: " + anual);
		System.out.println("La inflacion más alta se da en el mes de " + mes_max + " con " + masAlta);
		System.out.println("La inflacion más baja se da en el mes de " + mes_min + " con " + masBaja);
		System.out.println("El promedio de inflacion es: " + anual/12);
	}

}
