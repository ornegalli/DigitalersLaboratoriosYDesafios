package Módulo5;

public class desafio1 {

	public static void main(String[] args) {
		
		int[] vector = {10,20,5,15,30,20};
		
		int n, total = 0, maximo = vector[0], cont= 0;
		
		for(n = 0; n < vector.length;n++) {
			if(n%2 ==1) {
				System.out.println("Posicion impar " + n + "  valor: " + vector[n]);
			}
			total += vector[n];
			if(vector[n] > maximo) {
				maximo = vector[n];
			}
			if(vector[n] == 20) {
				cont++;
			}
		}
		System.out.println("El valor mayor del vector es: " + maximo);
		System.out.println("El total de los valores del vector es igual a " + total);
		System.out.println("El valor 20 aparecio " + cont +" veces");
		
	}

}
