package Módulo4;

import java.util.Scanner;

public class laboratorioDoWhile {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		int num;
		int suma = 0;
		
		int numeroMayor = -2147483648;
		int numeroMenor = 2147483647;
		
		System.out.println("Ingrese un numero entero, para culminar escriba 0");
		num = teclado.nextInt();


		do{
			
			suma += num;
			
			System.out.println("Ingrese un numero entero, para culminar escriba 0");
			num = teclado.nextInt();
			
			if (num > numeroMayor) {
				numeroMayor = num;
			}

			if (num < numeroMenor && num != 0) {
				numeroMenor = num;
			}
			
		}
		while(num != 0);
		
		System.out.println("La suma total es " + suma);
		System.out.println("El numero mayor es " + numeroMayor);
		System.out.println("El numero menor es " + numeroMenor);
		
		
		teclado.close();
	}
	

}
