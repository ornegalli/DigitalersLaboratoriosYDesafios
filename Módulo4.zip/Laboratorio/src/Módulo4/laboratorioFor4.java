package Módulo4;

public class laboratorioFor4 {

	public static void main(String[] args) {
		int suma = 0;
		
		for(int n = 0; n<=10; n++) {
			
			if (n % 2 == 1) {
				suma += n;
			}
			
		}
		
		System.out.println("La suma de numeros impares del 1 al 10 es: " + suma);

	}

}
