package Módulo4;

public class laboratorioWhile2 {

	public static void main(String[] args) {
		int n = 1;
		
		while(n <= 10) {
			if(n != 2 && n != 5 && n != 9) {
				System.out.println(n);
			}
		n++;
		}
	}

}
