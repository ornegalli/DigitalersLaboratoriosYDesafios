package Módulo4;

public class laboratorioFor9y10 {

	public static void main(String[] args) {
		
		System.out.println("Laboratorio 9: ");
		
		int i,j;
		
		for( i = 1; i <= 5; i++) {
			for(j = 6; j > i; j--) {
				System.out.print("@");
			}
			System.out.println();
		}
		
		/*PARA i DESDE 1 HASTA 5 CON i=i+1 HACER
		 PARA j DESDE 6 MIENTRAS j > i CON j=j-1 HACER
				 ESCRIBIR “@”
				  FIN PARA
				  HACER salto de linea
				 FIN PARA
*/
	
	
		
		System.out.println("Laboratorio 10: ");
		
		int cantInicial=1;
		 int cantMedia=4;
		 int incremento=1;
		 int cantFinal=cantInicial-incremento;
		 int cantArrobas=0;
		 int cantArrobasLinea=cantInicial;
		 int contadorLineas=0;
		 
		 while(cantArrobasLinea!=cantFinal || contadorLineas==0){
		 
			 for(cantArrobas=1;cantArrobas<=cantArrobasLinea;cantArrobas++){
				 System.out.print("@");
			 }
			 
			 System.out.println();
			 
			 cantArrobasLinea+=incremento;
			 
			 if(cantArrobasLinea==cantMedia){
			 incremento=-incremento;
			 }
			 contadorLineas++;
			 }
		
	
	
		 }
		 


	}


