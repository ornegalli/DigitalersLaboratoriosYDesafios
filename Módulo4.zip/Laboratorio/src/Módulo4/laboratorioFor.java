package Módulo4;

import java.util.Scanner;

public class laboratorioFor {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);

		int cantidadRepeticiones = 0;
		String oracion = "";
	
		do {
			System.out.println("Indique la oracion a evaluar (No puede estar vacia)");
			oracion = teclado.nextLine();
		} while (oracion.length() == 0);
		
		// asumimos el primer caracter como el que mas se repite
		char caracter = oracion.charAt(0);

		
		for (int i = 0; i < oracion.length(); i++) {
			
			char caracterAux = oracion.charAt(i);  // utilizamos auxiliares para poder comparar y sustituir
			int contadorAuxiliar = 0;

			if (caracterAux == ' ') {
				continue;
			}

			for (int j = 0; j < oracion.length(); j++) {
				if (caracterAux == oracion.charAt(j)) {
					contadorAuxiliar++;
				}

			}

			// si el caracter se repite mas veces que el anterior guardado lo sustituimos
			if (contadorAuxiliar > cantidadRepeticiones) {
				caracter = caracterAux;
				cantidadRepeticiones = contadorAuxiliar;
			}

		}

		System.out.println("El caracter [" + (caracter) + "] se repite " + cantidadRepeticiones + " veces");

		teclado.close();

	

	}

}
