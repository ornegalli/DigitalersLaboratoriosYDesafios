package Módulo4;

import java.util.Scanner;

public class laboratorioWhile {

	public static void main(String[] args) {
	 Scanner teclado = new Scanner(System.in);
	 
	 int suma = 0;
	 
	 System.out.println("Para salir escriba 0, de lo contrario ingrese cualquier numero");
	 	int numero = teclado.nextInt();
	 
	 while(numero != 0) {
	
		 suma += numero;
		
	 System.out.println("Para culminar escriba 0, de lo contrario ingrese cualquier numero");
		 numero = teclado.nextInt();
	 
	 }
	 
	 System.out.println("La suma total es " + suma);
	 
	 teclado.close();
}
}
