package Módulo4;

public class laboratorioFor7y8 {

	public static void main(String[] args) {
		
		System.out.println("Laboratorio 7: ");
		
		for(int i = 1; i <= 5; i++) {
			
			if(i == 2 || i == 4) {
				System.out.println("@@");
			}else {
				System.out.println("@");
			}
		}
	System.out.println("Laboratorio 8: ");
	
	String x="";
	
	 for(int i = 1; i <= 5; i++) {
		
		 x = x + "@";
		 
		 System.out.println(x);
	 }
	
	}

}
