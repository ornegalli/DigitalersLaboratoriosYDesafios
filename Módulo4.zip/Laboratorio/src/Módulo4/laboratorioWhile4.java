package Módulo4;

public class laboratorioWhile4 {

	public static void main(String[] args) {
		int n = 1, suma = 0;
		
		while(n <= 10) {
			suma += n;
			
			n++;
		}
		
		System.out.println("La suma de numeros del 1 al 10 es igual a " + suma);
		
	}

}
