package Módulo4;

public class laboratorioWhile3 {

	public static void main(String[] args) {
		
		int n = 1;
		
		while(n <= 30) {
		
			if(n < 10 || n > 20) {
				System.out.println(n);
			}
			
			n++;
		}

	}

}
