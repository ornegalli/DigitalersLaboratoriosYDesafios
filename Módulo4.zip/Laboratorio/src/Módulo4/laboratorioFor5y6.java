package Módulo4;

public class laboratorioFor5y6 {

	public static void main(String[] args) {
		
		System.out.println("Laboratorio 5: ");
		
		int multi = 1, suma = 0;
		
		for(int i = 1; i <= 5; i++) {
			multi *= i;
		}
		
		for(int j = 1; j <= 5; j++) {
			suma += j;
		}
		
		System.out.println();
		System.out.println("La resta de " + multi + " y " + suma + " da como resultado: " + (multi - suma));
		
		System.out.println();
		
		System.out.println("Laboratorio 6: ");
			
			for(int i = 0; i < 4; i++) {
				System.out.println("@");
			}
	}

}
