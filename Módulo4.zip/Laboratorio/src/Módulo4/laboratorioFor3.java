package Módulo4;

public class laboratorioFor3 {

	public static void main(String[] args) {
		for(int i = 10; i >= 1; i--) {
			
			System.out.println(i);
		
		}

	}

}
