package Módulo4;

public class desafio {

	public static void main(String[] args) {
		System.out.println("Ejercicio 1: ");
		
		for(int i = 1; i <= 10; i++) {
			System.out.println(i);
		}

		System.out.println("Ejercicio 2: ");
		
		int mes = 1;
		float dinero = 1000;
		
		for(mes = 1; mes <= 12; mes++) {
			dinero *= 1.02;	
		};
		
		System.out.println("El resultado al cabo de un año es " + dinero);
	
		System.out.println("Ejercicio 3: ");
		
		int n = 0, suma = 0;
		
		for(n = 0; n <= 25; n++) {
			
			if( n%2 == 0) {
			suma += n;
			}
		}
		
		System.out.println("La suma de los numeros pares del 1 al 25 es igual a  " + suma);
	}

}
