package Módulo3;

import java.util.Scanner;

public class laboratorioIfElse {

	public static void main(String[] args) {

		Scanner teclado = new Scanner(System.in);
		
		String usuario = "usuario", contraseña = "contraseña";

		System.out.println("Ingrese su usuario");
		usuario = teclado.nextLine();
		System.out.println("Ingrese su contraseña");
		contraseña = teclado.nextLine();
		
		if(usuario.equals("usuario") && contraseña.equals("contraseña")) {
			System.out.println("Bienvenidos al Sistema");
		}else {
			System.out.println("Credenciales incorrectas");
		}
		
		teclado.close();
	}

}
