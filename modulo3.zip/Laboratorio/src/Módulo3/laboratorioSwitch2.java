package Módulo3;

import java.util.Scanner;

public class laboratorioSwitch2 {

	public static void main(String[] args) {
	
		Scanner teclado = new Scanner(System.in);
		int n1, n2;
		String opcion;
		
		System.out.println("Ingrese el primer número: ");
		n1 = teclado.nextInt();
		System.out.println("Ingrese el segundo número: ");
		n2 = teclado.nextInt();
		System.out.println("1-suma 2-resta 3-producto 4-division: ");
		opcion = teclado.next();
		
		switch(opcion) {
		
		case "suma" : System.out.println("Resultado: " + (n1 + n2));break;
		case "resta" : System.out.println("Resultado: " + (n1 - n2));break;
		case "producto" : System.out.println("Resultado: " + (n1 * n2));break;
		case "division" : System.out.println("Resultado: " + (n1 / n2));break;
		
		}
	
	teclado.close();
	}

}
