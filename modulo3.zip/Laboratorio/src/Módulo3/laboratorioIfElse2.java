package Módulo3;

public class laboratorioIfElse2 {
	public static void main(String[] args) {
		
		int temperatura = 5;
		String tiempo = "Nieve";
		
		if(temperatura > 25 && tiempo.equalsIgnoreCase("Soleado")) {
			System.out.println("Puede caminar y tomar sol");
			} else if ((temperatura > 15 && temperatura <= 25) && tiempo.equalsIgnoreCase("Soleado")){
						System.out.println("Puede caminar");
			} else if (temperatura <=15 && tiempo.equalsIgnoreCase("Soleado")){
							System.out.println("Puede caminar con campera");
			}  else if (temperatura < 10 && tiempo.equalsIgnoreCase("Lluvia")){
				System.out.println("Debe quedarse en casa o caminar con paraguas y campera");
	}else {
		System.out.println("Puede salir a esquiar");
	}
	}
	
}
