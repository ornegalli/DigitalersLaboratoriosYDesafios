package Módulo2;

import java.util.Scanner;

public class laboratorioCasteo {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in); 
		
		System.out.println("Ingrese un numero decimal: ");
		float numeroDecimal = teclado.nextFloat();
		
		System.out.println("Ingrese otro numero decimal: ");
		float otroDecimal = teclado.nextFloat();
		
		float multiplicacion = numeroDecimal * otroDecimal;
		double multiPrecisa = multiplicacion;
		int multiSinDecimales = (int) multiplicacion;
		float division = numeroDecimal / otroDecimal;
		double divisionPrecisa = division;
		int divisionSinDecimales = (int) division;
		float suma =  numeroDecimal + otroDecimal;
		double sumaPrecisa = suma;
		int sumaSinDecimales = (int) suma;
		float resta = numeroDecimal - otroDecimal;
		double restaPrecisa = resta;
		int restaSinDecimales = (int) resta;
		
		System.out.println("Multiplicacion con redondeo: " + multiSinDecimales);
		System.out.println("Multiplicacion precisa: " + multiPrecisa);
		System.out.println("Division con redondeo: " + divisionSinDecimales);
		System.out.println("Division precisa: " + divisionPrecisa);
		System.out.println("Suma con redondeo: " + sumaSinDecimales);
		System.out.println("Suma precisa: " + sumaPrecisa);
		System.out.println("Resta con redondeo: " + restaSinDecimales);
		System.out.println("Resta precisa: " + restaPrecisa);

		teclado.close();
		
	}

}
