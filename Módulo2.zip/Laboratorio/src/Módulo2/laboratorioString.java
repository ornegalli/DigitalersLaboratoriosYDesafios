package Módulo2;

import java.util.Scanner;

public class laboratorioString {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Ingrese un parrafo: ");
		String parrafo1 = teclado.nextLine();
		
		System.out.println("Ingrese otro parrafo: ");
		String parrafo2 = teclado.nextLine();
		
		System.out.println("Los parrafos son iguales bit a bit? " + (parrafo1 == parrafo2));
		System.out.println("Los parrafos son iguales en contenido? " + (parrafo1.equalsIgnoreCase(parrafo2)));
		System.out.println("Parrafos en mayusculas: " );
		System.out.println(parrafo1.toUpperCase() + "\n" + parrafo2.toUpperCase() );
		System.out.println("Parrafos en minusculas: " );
		System.out.println(parrafo1.toLowerCase() + "\n" + parrafo2.toLowerCase() );
		
		System.out.println("Primera letra en Mayusculas:");
		String parrafo1PrimerLetraMayus = parrafo1.substring(0, 1).toUpperCase() + parrafo1.substring(1).toLowerCase();
		System.out.println(parrafo1PrimerLetraMayus);
		String parrafo2PrimerLetraMayus = parrafo2.substring(0, 1).toUpperCase() + parrafo2.substring(1).toLowerCase();
		System.out.println(parrafo2PrimerLetraMayus);
		System.out.println(String.join(" , ", parrafo1, parrafo2));

		teclado.close(); 
	}

}
