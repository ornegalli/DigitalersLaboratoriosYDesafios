package Módulo2;

import java.util.Scanner;

public class ej2Math {

	public static void main(String[] args) {

		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Ingrese una palabra");
		String palabra = teclado.nextLine();
		
		int palabraNum = (int) ((Math.random()* 25) + 97);
		
		char palabraLetra = (char) palabraNum;
		
		System.out.println("El numero generado para la palabra ingresada es " + palabraNum + ", este numero representa la letra " + palabraLetra);
		
		System.out.println("La letra " + palabraLetra + " se encuentra en " + palabra + "? " + palabra.contains(String.valueOf(palabraLetra)));
		
		
		teclado.close();
	

	}

}
