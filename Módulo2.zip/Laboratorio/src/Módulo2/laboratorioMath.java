package Módulo2;

public class laboratorioMath {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int intensidadRojo;
		int intensidadVerde;
		int intensidadAzul;
		int maximo = 255;
		
		intensidadRojo = (int) (Math.random() * maximo);
		intensidadVerde = (int) (Math.random() * maximo);
		intensidadAzul = (int) (Math.random() * maximo);
		
		System.out.println("Color RGB(" + intensidadRojo + ", " + intensidadVerde + ", " + intensidadAzul + ")");

	}

}
