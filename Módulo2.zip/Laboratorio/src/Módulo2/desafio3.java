package Módulo2;

import java.util.Scanner;

public class desafio3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);
		String letra1, letra2;
		int ascii1, ascii2;
		char caracter1, caracter2;
		
		
System.out.println("Ingrese una letra");
letra1 = teclado.next();
System.out.println("Ingrese otra letra");
letra2 = teclado.next();

caracter1 = letra1.toLowerCase().charAt(0);
ascii1 = caracter1;
caracter2 = letra2.toLowerCase().charAt(0);
ascii2 = caracter2;

System.out.println("Minusculas: ");
System.out.println("La letra " + caracter1 + " en ascii representa el numero " + ascii1);
System.out.println("La letra " + caracter2 + " en ascii representa el numero " + ascii2);

caracter1 = letra1.toUpperCase().charAt(0);
ascii1 = caracter1;
caracter2 = letra2.toUpperCase().charAt(0);
ascii2 = caracter2;

System.out.println("Mayusculas: ");
System.out.println("La letra " + caracter1 + " en ascii representa el numero " + ascii1);
System.out.println("La letra " + caracter2 + " en ascii representa el numero " + ascii2);
		teclado.close();
	}

}
