package Módulo2;

import java.util.Scanner;

public class desafio1 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in); 

		System.out.println("Ingrese su nombre y su apellido");
		String nombre = teclado.next();
		String apellido = teclado.next();
		System.out.println("El nombre es " + nombre.substring(0,1).toUpperCase() + nombre.substring(1).toLowerCase());
		System.out.println("El apellido es " + apellido.substring(0,1).toUpperCase() + apellido.substring(1).toLowerCase());
		
		
		teclado.close();		
	}

}
