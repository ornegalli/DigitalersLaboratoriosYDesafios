package Módulo2;

import java.util.Scanner;

public class desafio2 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		float base, exponente;
		double resultado;
		int cantidadDecimales;
		
		System.out.println("Ingrese un numero base");
		base = teclado.nextFloat();
		System.out.println("Ingrese un numero exponente");
		exponente = teclado.nextFloat();
		
		System.out.println("¿Cuantos decimales desea ver en el resultado?");
		cantidadDecimales = teclado.nextInt();
		
		resultado = Math.pow(base, exponente);
		System.out.println(String.format("La potencia con " + cantidadDecimales + " decimales: %." + cantidadDecimales + "f ", resultado));
	
	teclado.close();
	}

}
