package Módulo3;

public class desafio2 {

	public static void main(String[] args) {

		int a = 10, b = -2, c = 5;
		
		if(a > 0 && b > 0) {
			System.out.println(a*b);
		}else if(a > 0 && c > 0) {
			System.out.println(a*c);
		}else if(b > 0 && c > 0) {
			System.out.println(b*c);
		}

	}

}
