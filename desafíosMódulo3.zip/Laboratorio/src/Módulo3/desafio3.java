package Módulo3;

public class desafio3 {

	public static void main(String[] args) {
		String usuario = "Pepito", clave = "1234";


		if(usuario.equals("Pepito") && clave.equals("1234")) {
			System.out.println("¡Bienvenido Pepito!");
	}
		else if(usuario.equals("Pepito") && clave != "1234")
	{
		System.out.println("Contraseña incorrecta");
	}
		else if(!(usuario.equals("Pepito")) && clave.equals("1234")){
		System.out.println("Usuario incorrecto");
	}
		else {
		System.out.println("El usuario o la clave ingresada no es correcta");
	}

}
}
