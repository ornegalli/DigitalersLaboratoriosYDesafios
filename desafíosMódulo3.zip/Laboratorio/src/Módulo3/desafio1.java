package Módulo3;

public class desafio1 {

	public static void main(String[] args) {
		
		int n1 = 100, n2 = 500, n3 = 250;
		
		if(n1 > n2 && n1 >n3) {
			System.out.println("El n1 es el mayor");
		}else if(n2 > n1 && n2 > n3) {
			System.out.println("El n2 es el mayor");
		}else if(n3 > n1 && n3 > n2) {
			System.out.println("El n3 es el mayor");
		}

	}

}
